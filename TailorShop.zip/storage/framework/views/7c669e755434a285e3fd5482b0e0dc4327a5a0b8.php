<?php
    $prefix = Request::route()->getPrefix();
    $route = Route::current()->getName();
?>

<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('home')); ?>" class="brand-link">

        <span class="brand-text font-weight-light">Tailor Management</span>
    </a>
    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="<?php echo e(asset('storage/profile/'.Auth::user()->image)); ?>" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block"><?php echo e(Auth::user()->name); ?></a>
            </div>
        </div>
        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <!-- Add icons to the links using the .nav-icon class
                     with font-awesome or any other icon font library -->

                <li class="nav-item">
                    <?php
                       use Illuminate\Support\Str;
                       $user_role = Str::lower(Auth::user()->role->role_name);
                    ?>
                    <a href="<?php echo e(route($user_role.".dashboard")); ?>" class="nav-link">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Dashboard
                        </p>
                    </a>
                </li>

<?php if(Auth::user()->role_id == 1): ?>

                <li class="nav-item has-treeview <?php echo e(($prefix == "admin/user")?'menu-open':''); ?>">
                    <a href="#" class="nav-link <?php echo e(($prefix == "admin/user")?'active':''); ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            User Management
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.user.index')); ?>" class="nav-link <?php echo e(($route == "admin.user.index")?'active':''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>View User List</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.user.create')); ?>" class="nav-link <?php echo e(($route == "admin.user.create")?'active':''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p> Create User</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item has-treeview <?php echo e(($prefix == "admin/category")?'menu-open':''); ?>">
                    <a href="#" class="nav-link <?php echo e(($prefix == "admin/category")?'active':''); ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Category Management
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.category.index')); ?>" class="nav-link <?php echo e(($route == "admin.category.index")?'active':''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>View Category List</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.category.create')); ?>" class="nav-link <?php echo e(($route == "admin.category.create")?'active':''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p> Create Category</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item has-treeview <?php echo e(($prefix == "admin/tag")?'menu-open':''); ?>">
                    <a href="#" class="nav-link <?php echo e(($prefix == "admin/tag")?'active':''); ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Tag Management
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.tag.index')); ?>" class="nav-link <?php echo e(($route == "admin.tag.index")?'active':''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>View Tag List</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.tag.create')); ?>" class="nav-link <?php echo e(($route == "admin.tag.create")?'active':''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p> Create Tag</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item has-treeview <?php echo e(($prefix == "admin/dress")?'menu-open':''); ?>">
                    <a href="#" class="nav-link <?php echo e(($prefix == "admin/dress")?'active':''); ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Dress Management
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.dress.index')); ?>" class="nav-link <?php echo e(($route == "admin.dress.index")?'active':''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>View Dress List</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.dress.create')); ?>" class="nav-link <?php echo e(($route == "admin.dress.create")?'active':''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p> Create Dress</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.dress.pending')); ?>" class="nav-link <?php echo e(($route == "admin.dress.pending")?'active':''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p> Pending Design List</p>
                            </a>
                        </li>
                    </ul>
                </li>
                    <li class="nav-item has-treeview <?php echo e(($prefix == "order")?'menu-open':''); ?>">
                        <a href="#" class="nav-link <?php echo e(($prefix == "order")?'active':''); ?>">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>
                                Order Management
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.order.index')); ?>" class="nav-link <?php echo e(($route == "admin.order.index")?'active':''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>View Orders</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item has-treeview <?php echo e(($prefix == "profile")?'menu-open':''); ?>">
                        <a href="#" class="nav-link <?php echo e(($prefix == "profile")?'active':''); ?>">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>
                                Profile
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('profile.view')); ?>" class="nav-link <?php echo e(($route == "profile.view")?'active':''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>View Profile</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('profile.newPassword')); ?>" class="nav-link <?php echo e(($route == "profile.newPassword")?'active':''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p> Change Password</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item has-treeview <?php echo e(($prefix == "settings")?'menu-open':''); ?>">
                        <a href="#" class="nav-link <?php echo e(($prefix == "settings")?'active':''); ?>">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>
                                Settings
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.slider.list')); ?>" class="nav-link <?php echo e(($route == "admin.slider.list")?'active':''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p> Slider List</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.slider.create')); ?>" class="nav-link <?php echo e(($route == "admin.slider.create")?'active':''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Create Slider</p>
                                </a>
                            </li>
                        </ul>
                    </li>


                <?php elseif(Auth::user()->role_id == 2): ?>

                    <li class="nav-item has-treeview <?php echo e(($prefix == "staff/dress")?'menu-open':''); ?>">
                        <a href="#" class="nav-link <?php echo e(($prefix == "staff/dress")?'active':''); ?>">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>
                                Dress Management
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('staff.dress.index')); ?>" class="nav-link <?php echo e(($route == "staff.dress.index")?'active':''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>View Dress List</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('staff.dress.create')); ?>" class="nav-link <?php echo e(($route == "staff.dress.create")?'active':''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p> Create Dress</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item has-treeview <?php echo e(($prefix == "staff/order")?'menu-open':''); ?>">
                        <a href="#" class="nav-link <?php echo e(($prefix == "staff/order")?'active':''); ?>">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>
                                Order Management
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('staff.order.index')); ?>" class="nav-link <?php echo e(($route == "staff.order.index")?'active':''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>View Order List</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item has-treeview <?php echo e(($prefix == "profile")?'menu-open':''); ?>">
                        <a href="#" class="nav-link <?php echo e(($prefix == "profile")?'active':''); ?>">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>
                                Profile
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('profile.view')); ?>" class="nav-link <?php echo e(($route == "profile.view")?'active':''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>View Profile</p>
                                </a>
                            </li>
                        </ul>
                    </li>


                    

                <?php elseif(Auth::user()->role_id == 3): ?>
                    <li class="nav-item has-treeview <?php echo e(($prefix == "order")?'menu-open':''); ?>">
                        <a href="#" class="nav-link <?php echo e(($prefix == "order")?'active':''); ?>">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>
                                Order Management
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('customer.cart.order.list')); ?>" class="nav-link <?php echo e(($route == "customer.cart.order.list")?'active':''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>View Orders</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item has-treeview <?php echo e(($prefix == "profile")?'menu-open':''); ?>">
                        <a href="#" class="nav-link <?php echo e(($prefix == "profile")?'active':''); ?>">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>
                                Profile
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('profile.view')); ?>" class="nav-link <?php echo e(($route == "profile.view")?'active':''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>View Profile</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('profile.newPassword')); ?>" class="nav-link <?php echo e(($route == "profile.newPassword")?'active':''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p> Change Password</p>
                                </a>
                            </li>
                        </ul>
                    </li>


                <?php endif; ?>


                <li class="nav-item">
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                       document.getElementById('logout-form').submit();">
                        <i class="fas fa-power-off"></i>
                        <?php echo e(__('Logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\xampp\htdocs\TailorShop\resources\views/layouts/backend/partial/sidebar.blade.php ENDPATH**/ ?>