<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- Page -->
<!-- Page -->
<div class="page-area cart-page spad">
    <div class="container">
        <form  action="<?php echo e(route('customer.cart.order')); ?>" method="post" class="checkout-form" id="payment-form">
            <?php echo csrf_field(); ?>
            <div class="row">
                <?php if($user_info->count() > 0): ?>
                    <div class="col-lg-6">
                        <h4 class="checkout-title">Billing Address</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <input type="text" placeholder="First Name *" name="name" value="<?php echo e(Auth::user()->name); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" placeholder="E-mail *" name="email" value="<?php echo e(Auth::user()->email); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" placeholder="Phone *" name="phone" value="<?php echo e($user_info->phone); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" placeholder="Phone *" name="house" value="<?php echo e($user_info->house); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" placeholder="Phone *" name="road" value="<?php echo e($user_info->road); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" placeholder="Phone *" name="zone" value="<?php echo e($user_info->zone); ?>">
                            </div>
                            <div class="col-md-12">
                                <input type="text" placeholder="Phone *"  class="text-center" name="city" value="<?php echo e($user_info->city); ?>">
                            </div>

                        </div>
                    </div>
                <?php else: ?>
                <h4>Please fill the form manually or update your information</h4>
                    <div class="col-lg-6">
                        <h4 class="checkout-title">Billing Address</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <input type="text" placeholder="First Name *" name="name" value="<?php echo e(Auth::user()->name); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" placeholder="E-mail *" name="email" value="<?php echo e(Auth::user()->email); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" placeholder="Phone *" name="phone" value="<?php echo e($user_info->phone); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" placeholder="Phone *" name="house" value="<?php echo e($user_info->house); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" placeholder="Phone *" name="road" value="<?php echo e($user_info->road); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" placeholder="Phone *" name="zone" value="<?php echo e($user_info->zone); ?>">
                            </div>
                            <div class="col-md-12">
                                <input type="text" placeholder="Phone *"  class="text-center" name="city" value="<?php echo e($user_info->city); ?>">
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="col-lg-6">
                    <div class="order-card">
                        <div class="order-details">
                            <div class="od-warp">
                                <h4 class="checkout-title">Your order</h4>
                                <table class="order-table">
                                    <thead>
                                    <tr>
                                        <th>No Of Items</th>
                                        <th>Total</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td><?php echo e($total_item); ?></td>
                                        <td><?php echo e($total_amount); ?></td>
                                        <input type="hidden" name="total" value="<?php echo e($total_amount); ?>">
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="form-group col-md-8">
                                    <label>Select Possible Delivery Date</label>
                                    <input type="date" name="date" min="<?php echo e($today); ?>" class="form-control">
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="site-btn btn-full">
                            Place Order</button>
                    </div>
                </div>
            </div>
        </form>

        <div class="container" style="margin-top:10%;margin-bottom:10%">
            <div class="row justify-content-center">

            </div>
        </div>

    </div>
</div>
<!-- Page -->
<!-- Page end -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TailorShop\resources\views/cart/checkout.blade.php ENDPATH**/ ?>