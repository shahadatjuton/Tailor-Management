
<?php /**PATH C:\xampp\htdocs\TailorShop\resources\views/layouts/frontend/partial/slider.blade.php ENDPATH**/ ?>