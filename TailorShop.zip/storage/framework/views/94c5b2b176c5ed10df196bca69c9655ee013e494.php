<?php $__env->startSection('content'); ?>

    <section class="hero-section set-bg" data-setbg="img/bg.jpg">
        <div class="hero-slider owl-carousel">
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="hs-item">
                <div class="hs-left"><img src="<?php echo e(asset('storage/slider/'.$slider->image)); ?>" alt="<?php echo e($slider->title); ?>"></div>
                <div class="hs-right">
                    <div class="hs-content">
                        <div class="price"><?php echo e($slider->title); ?></div>
                        <h2><?php echo e($slider->description); ?></h2>
                        <p class="site-btn">Shop NOW!</p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




















        </div>
    </section>
<!-- Product section -->
<section class="product-section spad">
    <div class="container">
        <div class="row" id="product-filter">
            <?php $__empty_1 = true; $__currentLoopData = $dresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="mix col-lg-3 col-md-6 best">
                <div class="product-item">
                    <figure>
                        <img src="<?php echo e(asset('storage/dress/'.$dress->image)); ?>" alt="">
                        <div class="pi-meta">
                            <div class="pi-m-left">
                                <img src="<?php echo e(asset('assets/frontend/')); ?>/img/icons/eye.png" alt="">
                                <p>quick view</p>
                            </div>
                            <div class="pi-m-right">
                                <img src="<?php echo e(asset('assets/frontend/')); ?>/img/icons/heart.png" alt="">
                                <p>save</p>
                            </div>
                        </div>
                    </figure>
                    <div class="product-info">
                        <h6><?php echo e($dress->title); ?></h6>
                        <p><?php echo e($dress->price); ?></p>
                        <a href="<?php echo e(route('dress.show',$dress->id)); ?>" class="site-btn btn-line">View More</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="bg-danger">
                    <h4>There is no design available yet!</h4>
                </div>
            <?php endif; ?>





























































































































































        </div>
    </div>
</section>
<!-- Product section end -->


<!-- Blog section -->













































<!-- Blog section end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TailorShop\resources\views/welcome.blade.php ENDPATH**/ ?>