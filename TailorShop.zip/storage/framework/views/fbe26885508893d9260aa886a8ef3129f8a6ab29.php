<?php $__env->startSection('content'); ?>
<!-- Page -->
<div class="page-area cart-page spad">
    <div class="container">
        <div class="cart-table table-responsive">
            <table>
                <thead>
                <tr>
                    <th class="product-th">Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th class="total-th">Total</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="product-col">
                        <img src="<?php echo e(asset('storage/dress/'.(\App\Dress::find($cart->dress_id))->image)); ?>" alt="Design Image">
                        <div class="pc-title">
                            <h4><?php echo e((\App\Dress::find($cart->dress_id))->title); ?></h4>
                            <a href="#">Edit Product</a>
                        </div>
                    </td>
                    <td class="price-col"><?php echo e((\App\Dress::find($cart->dress_id))->price); ?></td>
                    <td class="quy-col">
                        <div class="quy-input">
                            <span>Qty</span>
                            <input  value="<?php echo e($cart->quantity); ?>" readonly>
                        </div>
                    </td>
                    <td class="total-col"><?php echo e((\App\Dress::find($cart->dress_id))->price * $cart->quantity); ?></td>
                        <td>
                            <a href="<?php echo e(route('customer.cart.destroy',$cart->id)); ?>" class="btn btn-danger float-right">Remove</a>
                        </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div>
                        <h4>There is no dress in cart list</h4>
                    </div>
                <?php endif; ?>
                <?php if($carts->count() > 0): ?>
                <tr>
                    <td colspan="3"></td>
                    <td>Grand Total </td>
                    <td>56789 Taka</td>
                </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="row cart-buttons">
            <div class="col-lg-5 col-md-5">
                <a href="<?php echo e(route('home')); ?>" class="site-btn btn-continue">Continue Shopping</a>

            </div>
            <div class="col-lg-7 col-md-7 text-lg-right text-left">
                <a href="<?php echo e(route('customer.cart.clear')); ?>" class="site-btn btn-line btn-update">Clear Cart</a>
                <a href="<?php echo e(route('customer.cart.checkout')); ?>" class="site-btn btn-continue">Checkout</a>
            </div>
        </div>
    </div>
</div>
<!-- Page end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TailorShop\resources\views/cart/cart.blade.php ENDPATH**/ ?>