<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="Tailor Management">
    <meta name="keywords" content="Tailor Management, eCommerce, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo e(config('app.name', 'Tailor-Management')); ?></title>


    <!-- Favicon -->
    <link href="<?php echo e(asset('assets/frontend/')); ?>/img/favicon.ico" rel="shortcut icon"/>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Stylesheets -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/')); ?>/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/')); ?>/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/')); ?>/css/owl.carousel.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/')); ?>/css/style.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/')); ?>/css/animate.css"/>
    <!-- Toaster css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/toastr.min.css')); ?>">
    <?php echo $__env->yieldPushContent('css'); ?>






</head>
<body>
<!-- Header section -->
<?php echo $__env->make('layouts.frontend.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Header section end -->
<?php echo $__env->yieldContent('content'); ?>
<!-- Footer section -->
<?php echo $__env->make('layouts.frontend.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer section end -->


<!--====== Javascripts & Jquery ======-->
<script src="<?php echo e(asset('assets/frontend/')); ?>/js/jquery-3.2.1.min.js"></script>
<script src="<?php echo e(asset('assets/frontend/')); ?>/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('assets/frontend/')); ?>/js/owl.carousel.min.js"></script>
<script src="<?php echo e(asset('assets/frontend/')); ?>/js/mixitup.min.js"></script>
<script src="<?php echo e(asset('assets/frontend/')); ?>/js/sly.min.js"></script>
<script src="<?php echo e(asset('assets/frontend/')); ?>/js/jquery.nicescroll.min.js"></script>
<script src="<?php echo e(asset('assets/frontend/')); ?>/js/main.js"></script>
<script src="<?php echo e(asset('assets/backend/js/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/backend/js/sweetalert2.all.min.js')); ?>"></script>
<?php echo Toastr::message(); ?>

<?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\TailorShop\resources\views/layouts/frontend/master.blade.php ENDPATH**/ ?>