<div>
    <header class="header-section header-normal">
        <div class="container-fluid">
            <!-- logo -->
            <div class="site-logo">
                <h2>Taylor Shop Management</h2>
            </div>
            <!-- responsive -->
            <div class="nav-switch">
                <i class="fa fa-bars"></i>
            </div>
            <div class="header-right">
                <a href="<?php echo e(route('customer.cart.index')); ?>" class="card-bag"><img src="<?php echo e(asset('assets/frontend/images/bag.png')); ?>" alt="">
                    <span><?php echo e(\App\Model\Cart::where('user_id',Auth::id())->count()); ?></span></a>

            </div>
            <!-- site menu -->

            <ul class="main-menu">
                <li class="active"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <?php if(Auth::user()): ?>
                    <?php
                        $user_role = Str::lower(Auth::user()->role->role_name);
                    ?>
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                       document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                    <li><a href="<?php echo e(route($user_role.".dashboard")); ?>"><?php echo e(Auth::user()->name); ?></a></li>
                <?php else: ?>
                <li><a href="<?php echo e(route('register')); ?>">Registration</a></li>
                <li><a href="<?php echo e(route('login')); ?>">Log In</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </header>

</div>
<?php /**PATH C:\xampp\htdocs\TailorShop\resources\views/layouts/frontend/partial/header.blade.php ENDPATH**/ ?>