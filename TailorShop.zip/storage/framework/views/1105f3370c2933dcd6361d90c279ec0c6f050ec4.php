<?php $__env->startSection('title', 'Manage Order'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Manage Order</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Order</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
          <section class="col-lg-12 ">
            <!-- Custom tabs (Charts with tabs)-->
            <div class="card">
              <div class="card-header">
               <h4>Order Details</h4>
                  <div class="text-right">
                      <a class="btn btn-info" href="<?php echo e(route('customer.pdf.invoice',$order->id)); ?>"><i class="fa fa-file-pdf-o"></i> Export as PDF</a>
                  </div>
              </div><!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-hover">
                    <thead>
                    <tr>
                        <th>SL No</th>
                        <th>Dress Name</th>
                        <th>Quantity</th>
                        <th>Total Amount</th>
                        <th>Instruction</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key +1); ?></td>
                        <td><?php echo e(\App\Dress::find($order->dress_id)->title); ?></td>
                        <td><?php echo e($order->quantity); ?></td>
                        <td><?php echo e($order->total); ?></td>
                        <td>
                            <?php if($order->instruction==null): ?>
                                <div class="bg-success">
                                    <p>All Right</p>
                                </div>
                             <?php else: ?>
                            <?php echo e(Str::limit($order->instruction,20)); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($order->status == 1): ?>
                                <div class="bg-warning">
                                    <p>Size requires changes</p>
                                </div>
                            <?php elseif($order->status == 2): ?>
                                <div class="bg-primary">
                                    <p>Size updated</p>
                                </div>
                            <?php else: ?>
                                <div class="bg-success">
                                    <p>All Right</p>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('customer.cart.order.size',$order->id)); ?>" class="btn btn-primary btn-sm" title="Edit">
                                <i class="fa fa-edit"></i>
                            </a>
                        </td>
                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
              </div><!-- /.card-body -->
            </div>
            <!-- /.card -->
            <!-- /.card -->
          </section>
          <!-- /.Left col -->
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TailorShop\resources\views/customer/orderDetails.blade.php ENDPATH**/ ?>