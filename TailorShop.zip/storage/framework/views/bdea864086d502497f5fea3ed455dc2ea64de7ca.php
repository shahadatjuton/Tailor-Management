<?php $__env->startSection('title', 'Manage Report'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->

    <link href="<?php echo e(asset('assets/backend/css/invoice.css')); ?>" rel="stylesheet">


    <!------ Include the above in your HEAD tag ---------->

    <!--Author      : @arboshiki-->
    <div id="invoice">

        <div class="toolbar hidden-print">
            <p style="margin-left: 400px">Total Orders</p>
            <div class="text-right">
                <a class="btn btn-info" href="<?php echo e(route('staff.pdf.total.order')); ?>"><i class="fa fa-file-pdf-o"></i> Export as PDF</a>
            </div>
            <hr>
        </div>
        <div class="invoice overflow-auto">
            <div style="min-width: 600px">
                <header>
                    <div class="row">
                        <div class="col">
                            <h4>TAYLOR MANAGEMENT SYSTEM</h4>
                        </div>
                        <div class="col company-details">
                            <div> 19/1, Panthapath,Dhaka – 1205, Bangladesh</div>
                            <div> <b>Phone:</b> +880123456789</div>

                            <div> <b>E-mail:</b> managementtailor@gmail.com</div>
                        </div>
                    </div>
                </header>
                <main>
                    <table border="0" cellspacing="0" cellpadding="0">
                        <thead>
                        <tr>
                            <th>Serial Number</th>
                            <th>Invoice Number</th>
                            <th>Delivery date</th>
                            <th>Amount</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $total_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key +1); ?></td>
                                <td><?php echo e($order->invoice_no); ?></td>
                                <td><?php echo e($order->possible_date); ?></td>
                                <td><?php echo e($order->total_amount); ?> <span>TAKA</span></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </main>


                <div class="float-right">
                    <div class="signature-right">
                        ........................
                        <h4>Signature</h4>
                    </div>
                </div>
            </div>
            <!--DO NOT DELETE THIS div. IT is responsible for showing footer always at the bottom-->
            <div></div>
        </div>
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TailorShop\resources\views/staff/report/total_order.blade.php ENDPATH**/ ?>